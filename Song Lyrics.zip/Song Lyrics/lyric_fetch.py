import requests
from bs4 import BeautifulSoup
import threading as T
import os

url = "https://gaana.com/lyrics/"

lyric=""


def grab_lyrics(song_NM):

    global lyric

    # song_name = input("\n\nEnter Song Name = ")
    Lyric_URL = requests.get(url+song_NM)
    # Status_Code = Lyric_URL.status_code
    content = BeautifulSoup(Lyric_URL.content,'html.parser')
    lyric_div = content.find('div', 'lyr_data')
    lyrics = lyric_div.find_all('p')
    
    for lyric in lyrics:
        # print("\nServer Status = ",Status_Code,"\nURL = ",Lyric_URL.url,"\nSong Name = ",song_NM,"\nSong Lyrics: ",lyric.text)
        html_generator(lyric, song_NM)



def html_generator(lyric, NM):
    os.chdir("template")
    with open("lyric.html","w") as fw:
        fw.write(f"<!Doctype html><html><head><title></title></head><body style='background-color:black; color:white; font-family: sans-serif'><div><center><h1>Song Name : {NM}<br><br><br>Song Lyrics: {lyric}<h1></center></div></body>")
        fw.close()


# grab_lyrics(song_NM)

