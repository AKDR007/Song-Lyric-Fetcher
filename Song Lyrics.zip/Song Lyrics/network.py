import socket as soc

IP_N = soc.gethostname()
IP_ADDR = soc.gethostbyname(IP_N)

print("\n\n",IP_ADDR)