from flask import Flask, render_template, render_template_string, redirect
import lyric_fetch as lf

app  = Flask(__name__, template_folder="template")

@app.route('/<song_name>')
def song_NM(song_name):
    lf.grab_lyrics(song_name)
    return render_template("lyric.html")

if __name__=='__main__':
    app.run(debug=True, host="192.168.1.5",port=7770) 