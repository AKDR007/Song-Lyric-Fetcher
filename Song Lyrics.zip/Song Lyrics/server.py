from flask import Flask
import lyric_fetch as lf

app  = Flask(__name__,template_folder="templates")

@app.route('/<song_name>')
def song_NM(song_name):
    
    lf.grab_lyrics(song_name)
    return "song_lyric.html"

if __name__=='__main__':
    app.run(debug=True, port=7770)